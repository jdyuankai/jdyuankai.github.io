package matchingalgorithm;

import datasource.DataSource;

public class MatchingAlgoSP extends MatchingAlgo {
	public String match(DataSource ds) {
		return null;
	}
}

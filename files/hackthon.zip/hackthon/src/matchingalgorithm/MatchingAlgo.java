package matchingalgorithm;

import datasource.DataSource;

public abstract class MatchingAlgo {
	public abstract String match(DataSource ds);
}

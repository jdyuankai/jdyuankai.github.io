package datatype;

public class User {
	public User(int user_id, String first_name, String last_name,
			String home_addr, int age, String gender, boolean has_car,
			int seat_num) {
		super();
		this.user_id = user_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.home_addr = home_addr;
		this.age = age;
		this.gender = gender;
		this.has_car = has_car;
		this.seat_num = seat_num;
	}

	public User(String line) {

	}

	public String toString() {
		return null;
	}

	int user_id;
	String first_name;
	String last_name;
	String home_addr;
	int age;
	String gender;
	boolean has_car;
	int seat_num;

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getHome_addr() {
		return home_addr;
	}

	public void setHome_addr(String home_addr) {
		this.home_addr = home_addr;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public boolean isHas_car() {
		return has_car;
	}

	public void setHas_car(boolean has_car) {
		this.has_car = has_car;
	}

	public int getSeat_num() {
		return seat_num;
	}

	public void setSeat_num(int seat_num) {
		this.seat_num = seat_num;
	}

}

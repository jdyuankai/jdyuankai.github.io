package datatype;

public class Event {

	int id;
	String start_addr;
	String end_addr;
	boolean has_car;
	int num_seat;
	int date;
	int early_time;
	int late_time;
	int must_time;
	boolean matched;

	public Event(int id, String start_addr, String end_addr, boolean has_car,
			int num_seat, int date, int early_time, int late_time, int must_time) {
		super();
		this.id = id;
		this.start_addr = start_addr;
		this.end_addr = end_addr;
		this.has_car = has_car;
		this.num_seat = num_seat;
		this.date = date;
		this.early_time = early_time;
		this.late_time = late_time;
		this.must_time = must_time;
		this.matched = false;
	}

	public Event(String line) {
		//TODO
	}

	public String toString() {
		//TODO
		return null;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStart_addr() {
		return start_addr;
	}

	public void setStart_addr(String start_addr) {
		this.start_addr = start_addr;
	}

	public String getEnd_addr() {
		return end_addr;
	}

	public void setEnd_addr(String end_addr) {
		this.end_addr = end_addr;
	}

	public boolean isHas_car() {
		return has_car;
	}

	public void setHas_car(boolean has_car) {
		this.has_car = has_car;
	}

	public int getNum_seat() {
		return num_seat;
	}

	public void setNum_seat(int num_seat) {
		this.num_seat = num_seat;
	}

	public int getDate() {
		return date;
	}

	public void setDate(int date) {
		this.date = date;
	}

	public int getEarly_time() {
		return early_time;
	}

	public void setEarly_time(int early_time) {
		this.early_time = early_time;
	}

	public int getLate_time() {
		return late_time;
	}

	public void setLate_time(int late_time) {
		this.late_time = late_time;
	}

	public int getMust_time() {
		return must_time;
	}

	public void setMust_time(int must_time) {
		this.must_time = must_time;
	}

	public boolean isMatched() {
		return matched;
	}

	public void setMatched(boolean matched) {
		this.matched = matched;
	}

}

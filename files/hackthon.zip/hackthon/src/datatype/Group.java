package datatype;

import java.util.Vector;

public class Group {
	public Group(int date, int total_commute_time) {
		super();
		this.date = date;
		this.total_commute_time = total_commute_time;
		this.event_list = new Vector<Event>();
	}

	Vector<Event> event_list;
	int date;
	int total_commute_time;

	public int valid_match(Event event) {
		//TODO
		return 1;
	}

	public void add_match_info(Event event) {
		//TODO
	}

	public Vector<Event> getEvent_list() {
		return event_list;
	}

	public void setEvent_list(Vector<Event> event_list) {
		this.event_list = event_list;
	}

	public int getTotal_commute_time() {
		return total_commute_time;
	}

	public void setTotal_commute_time(int total_commute_time) {
		this.total_commute_time = total_commute_time;
	}

	public int getDate() {
		return date;
	}

	public void setDate(int date) {
		this.date = date;
	}

	public String check_result(int id, int date) {
		//TODO
		return null;
	}

	public Group(String line) {
		//TODO
	}

	public String toString() {
		//TODO
		return null;

	}

}

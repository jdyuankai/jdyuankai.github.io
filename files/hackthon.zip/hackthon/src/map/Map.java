package map;

public abstract class Map {
	public abstract int calculate_distance(String a, String b);

}

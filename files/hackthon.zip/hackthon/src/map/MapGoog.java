package map;

public class MapGoog extends Map {

	@Override
	public int calculate_distance(String a, String b) {
		// TODO Auto-generated method stub
		return 0;
	}

}

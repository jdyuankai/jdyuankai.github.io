public class Simulator {
	public static void main(String args[]) {
		int num_person = Integer.valueOf(args[0]);
		int num_days = Integer.valueOf(args[1]);

		for (int i = 0; i < num_days; i++) {
			for (int j = 0; j < num_person; j++) {
				String req = generate_request();
				Server.run_mem_sp(req);
			}
		}

		int score = Server.evaluate();
		System.out.println("Score is " + score);
	}

	static String generate_request() {
		return null;
	}
}

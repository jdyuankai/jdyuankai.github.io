import matchingalgorithm.MatchingAlgo;
import matchingalgorithm.MatchingAlgoSP;
import datasource.DataSource;
import datasource.DataSourceMem;

public class Server {
	public static String run_mem_sp(String request) {
		String response = new String();
		try {
			DataSource ds = new DataSourceMem();
			MatchingAlgo algo = new MatchingAlgoSP();
			response = ds.process_msg(request, algo);
		} catch (Exception e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
		}
		return response;
	}

	public static int evaluate() {
		return 1;
	}
}

package datasource;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;

import matchingalgorithm.MatchingAlgo;
import datatype.Event;
import datatype.Group;
import datatype.User;

public class DataSourceMem extends DataSource {
	public Vector<User> user_list;
	public Vector<Group> group_list;
	public Vector<Event> event_list;

	@Override
	public String process_msg(String msg, MatchingAlgo algo) {
		try {
			this.populate();
		} catch (IOException ie) {
			;
		}
		String ret = new String();
		// TODO Auto-generated method stub
		String[] list = msg.split("|");
		if (list[0].equals("carpool")) {
			int id = Integer.valueOf(list[0].trim());
			String start_addr = list[1];
			String end_addr = list[2];
			boolean has_car = Boolean.valueOf(list[3]);
			int num_seat = Integer.valueOf(list[4]);
			int date = Integer.valueOf(list[5]);
			int early_time = Integer.valueOf(list[6]);
			int late_time = Integer.valueOf(list[7]);
			int must_time = Integer.valueOf(list[8]);

			Event event = new Event(id, start_addr, end_addr, has_car,
					num_seat, date, early_time, late_time, must_time);
			event_list.add(event);
			ret = "OK, Finished storing information!\n";
			algo.match(this);
		} else if (list[0].equals("adduser")) {
			int user_id = Integer.valueOf(list[0]);
			String first_name = list[1];
			String last_name = list[2];
			String home_addr = list[3];
			int age = Integer.valueOf(list[4]);
			String gender = list[5];
			boolean has_car = Boolean.valueOf(list[6]);
			int seat_num = Integer.valueOf(list[7]);
			User user = new User(user_id, first_name, last_name, home_addr,
					age, gender, has_car, seat_num);
			user_list.add(user);
			ret = "OK, Finished registration information!\n";
		} else if (list[0].equals("checkresult")) {
			ret = this.check_result(list);
		}
		try {
			this.finalize();
		} catch (IOException ie) {
			;
		}
		return ret;
	}

	public String check_result(String[] list) {
		//TODO
		return null;
	}

	public void populate() throws IOException {
		this.user_list = new Vector<User>();
		this.group_list = new Vector<Group>();
		this.event_list = new Vector<Event>();
		//
		BufferedReader br = new BufferedReader(new FileReader("user.txt"));
		try {
			String line = br.readLine();

			while (line != null) {
				User user = new User(line);
				this.user_list.add(user);
				line = br.readLine();
			}
		} finally {
			br.close();
		}
		//
		br = new BufferedReader(new FileReader("event.txt"));
		try {
			String line = br.readLine();

			while (line != null) {
				Event event = new Event(line);
				this.event_list.add(event);
				line = br.readLine();
			}
		} finally {
			br.close();
		}
		//
		br = new BufferedReader(new FileReader("group.txt"));
		try {
			String line = br.readLine();

			while (line != null) {
				Group group = new Group(line);
				this.group_list.add(group);
				line = br.readLine();
			}
		} finally {
			br.close();
		}
	}

	public void finalize() throws IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File(
				"user.txt")));
		for (int i = 0; i < this.user_list.size(); i++) {
			writer.write(this.user_list.get(i).toString());
		}
		writer.close();
		writer = new BufferedWriter(new FileWriter(new File("event.txt")));
		for (int i = 0; i < this.user_list.size(); i++) {
			writer.write(this.event_list.get(i).toString());
		}
		writer.close();
		writer = new BufferedWriter(new FileWriter(new File("group.txt")));
		for (int i = 0; i < this.user_list.size(); i++) {
			writer.write(this.group_list.get(i).toString());
		}
		writer.close();
	}
}

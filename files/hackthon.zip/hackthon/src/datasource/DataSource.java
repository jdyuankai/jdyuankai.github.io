package datasource;

import matchingalgorithm.MatchingAlgo;

public abstract class DataSource  {
	public abstract String process_msg(String msg, MatchingAlgo algo);
}
